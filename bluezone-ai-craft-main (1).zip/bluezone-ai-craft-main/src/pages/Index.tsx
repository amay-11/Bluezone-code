import { useState, useCallback } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import ProblemSection from "@/components/ProblemSection";
import SolutionSection from "@/components/SolutionSection";
import ServicesSection from "@/components/ServicesSection";
import PricingSection from "@/components/PricingSection";
import GuaranteeSection from "@/components/GuaranteeSection";
import ResultsSection from "@/components/ResultsSection";
import ProcessSection from "@/components/ProcessSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import VideoPortfolioSection from "@/components/VideoPortfolioSection";
import TrustSection from "@/components/TrustSection";
import FAQSection from "@/components/FAQSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";
import EntryAnimation from "@/components/EntryAnimation";


const Index = () => {
  const [showContent, setShowContent] = useState(false);

  const handleAnimationComplete = useCallback(() => {
    setShowContent(true);
  }, []);

  return (
    <>
      <EntryAnimation onComplete={handleAnimationComplete} />
      <div className={`min-h-screen bg-background transition-opacity duration-500 ${showContent ? 'opacity-100' : 'opacity-0'}`}>
        <Header />
        <main>
          <HeroSection />
          <ProblemSection />
          <SolutionSection />
          <ServicesSection />
          <PricingSection />
          <GuaranteeSection />
          <ResultsSection />
          <ProcessSection />
          <TestimonialsSection />
          <VideoPortfolioSection />
          <TrustSection />
          <FAQSection />
          <CTASection />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default Index;
