import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import logoImage from "@/assets/bluezone-logo.png";

const EntryAnimation = ({ onComplete }: { onComplete: () => void }) => {
  const [phase, setPhase] = useState<"logo" | "reveal" | "done">("logo");

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("reveal"), 1800);
    const t2 = setTimeout(() => {
      setPhase("done");
      onComplete();
    }, 2600);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [onComplete]);

  return (
    <AnimatePresence>
      {phase !== "done" && (
        <motion.div
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-background"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
        >
          {/* Animated gradient orbs */}
          <motion.div
            className="absolute w-[600px] h-[600px] bg-[radial-gradient(circle,hsl(var(--blue-electric)/0.2)_0%,transparent_60%)]"
            animate={{ scale: [0, 1.5, 1], opacity: [0, 0.8, 0.4] }}
            transition={{ duration: 1.8, ease: "easeOut" }}
          />
          <motion.div
            className="absolute w-[400px] h-[400px] bg-[radial-gradient(circle,hsl(var(--cyan-glow)/0.15)_0%,transparent_60%)]"
            animate={{ scale: [0, 1.3, 1.1], opacity: [0, 0.6, 0.3] }}
            transition={{ duration: 2, ease: "easeOut", delay: 0.3 }}
          />

          {/* Logo */}
          <motion.div
            className="relative z-10 flex flex-col items-center gap-4"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1], delay: 0.2 }}
          >
            <motion.img
              src={logoImage}
              alt="BlueZone"
              className="h-16 md:h-20 w-auto drop-shadow-[0_0_30px_hsl(var(--cyan-glow)/0.4)]"
              animate={{ 
                filter: [
                  "drop-shadow(0 0 10px hsl(188 86% 53% / 0.2))",
                  "drop-shadow(0 0 30px hsl(188 86% 53% / 0.5))",
                  "drop-shadow(0 0 20px hsl(188 86% 53% / 0.3))",
                ]
              }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            />
            
            {/* Loading bar */}
            <motion.div
              className="h-0.5 bg-gradient-to-r from-primary via-accent to-primary rounded-full"
              initial={{ width: 0 }}
              animate={{ width: 120 }}
              transition={{ duration: 1.4, delay: 0.5, ease: "easeInOut" }}
            />
          </motion.div>

          {/* Curtain reveal effect */}
          {phase === "reveal" && (
            <>
              <motion.div
                className="absolute inset-0 bg-background origin-top"
                initial={{ scaleY: 1 }}
                animate={{ scaleY: 0 }}
                transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
                style={{ transformOrigin: "top" }}
              />
            </>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default EntryAnimation;
