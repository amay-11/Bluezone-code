import { MessageSquare, Globe, Cpu, CheckCircle2, Sparkles } from "lucide-react";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const SolutionSection = () => {
  const chatRef = useRef(null);
  const isInView = useInView(chatRef, { once: true, margin: "-100px" });

  return (
    <section className="py-24 relative section-glow overflow-hidden">
      <FloatingShapes variant="sparse" />
      
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-0 w-96 h-96 bg-blue-electric/5 rounded-full blur-[150px]" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-cyan-glow/5 rounded-full blur-[120px]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <AnimatedSection>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-glow/10 border border-cyan-glow/20 mb-6"
            >
              <Sparkles className="w-4 h-4 text-cyan-glow" />
              <span className="text-sm text-cyan-glow font-medium">AI-Powered Solution</span>
            </motion.div>
            
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-6">
              The Solution:{" "}
              <span className="text-gradient-blue animate-text-glow">Custom AI Agents</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              AI agents are intelligent virtual assistants designed specifically for your business. 
              Unlike generic chatbots, our agents understand your products, services, and customer needs.
            </p>

            <div className="space-y-6">
              {[
                {
                  icon: MessageSquare,
                  title: "WhatsApp & Website Integration",
                  description: "Deploy agents where your customers are — on your website and WhatsApp for seamless communication.",
                },
                {
                  icon: Globe,
                  title: "Business System Integration",
                  description: "Connect with your CRM, calendar, and internal tools for truly automated workflows.",
                },
                {
                  icon: Cpu,
                  title: "Custom-Built Intelligence",
                  description: "Trained on your specific business context — far beyond basic chatbot templates.",
                },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.15 }}
                  className="flex gap-4 p-4 rounded-xl bg-gradient-to-r from-[#0a1628]/60 to-transparent border border-cyan-glow/5 hover:border-cyan-glow/20 transition-all duration-300"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 shadow-[0_0_15px_hsl(var(--blue-electric)/0.15)]">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1 flex items-center gap-2">
                      {item.title}
                      <CheckCircle2 className="w-4 h-4 text-cyan-glow/50" />
                    </h3>
                    <p className="text-muted-foreground text-sm">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </AnimatedSection>

          {/* Right Visual */}
          <motion.div
            ref={chatRef}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
            className="relative"
          >
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,hsl(var(--cyan-glow)/0.1)_0%,transparent_60%)]" />
            
            {/* Decorative corner accents */}
            <div className="absolute -top-3 -left-3 w-8 h-8 border-l-2 border-t-2 border-cyan-glow/30 rounded-tl-lg" />
            <div className="absolute -top-3 -right-3 w-8 h-8 border-r-2 border-t-2 border-blue-electric/30 rounded-tr-lg" />
            <div className="absolute -bottom-3 -left-3 w-8 h-8 border-l-2 border-b-2 border-blue-electric/30 rounded-bl-lg" />
            <div className="absolute -bottom-3 -right-3 w-8 h-8 border-r-2 border-b-2 border-cyan-glow/30 rounded-br-lg" />

            <div className="relative bg-gradient-to-br from-[#0a1628] via-card to-[#081020] border border-cyan-glow/15 rounded-2xl p-8 shadow-elevated">
              {/* Live badge */}
              <div className="absolute -top-3 left-6 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0a1628] border border-cyan-glow/30">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-xs text-cyan-glow font-medium">Live Demo</span>
              </div>

              {/* Mock Chat Interface */}
              <div className="space-y-4 mt-2">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
                  transition={{ duration: 0.4, delay: 0.3 }}
                  className="flex items-start gap-3"
                >
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                    <span className="text-xs font-medium text-muted-foreground">U</span>
                  </div>
                  <div className="bg-muted rounded-lg rounded-tl-none px-4 py-2 max-w-[80%]">
                    <p className="text-sm text-foreground">Hi, I'd like to book an appointment for tomorrow</p>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.4, delay: 0.5 }}
                  className="flex items-start gap-3 flex-row-reverse"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-electric to-cyan-glow flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(34,211,238,0.3)]">
                    <Cpu className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-primary/10 border border-primary/20 rounded-lg rounded-tr-none px-4 py-2 max-w-[80%]">
                    <p className="text-sm text-foreground">
                      Hello! I'd be happy to help you schedule an appointment. I have openings tomorrow at 10:00 AM, 2:00 PM, and 4:30 PM. Which time works best for you?
                    </p>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
                  transition={{ duration: 0.4, delay: 0.7 }}
                  className="flex items-start gap-3"
                >
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                    <span className="text-xs font-medium text-muted-foreground">U</span>
                  </div>
                  <div className="bg-muted rounded-lg rounded-tl-none px-4 py-2 max-w-[80%]">
                    <p className="text-sm text-foreground">2:00 PM works great</p>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.4, delay: 0.9 }}
                  className="flex items-start gap-3 flex-row-reverse"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-electric to-cyan-glow flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(34,211,238,0.3)]">
                    <Cpu className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-primary/10 border border-primary/20 rounded-lg rounded-tr-none px-4 py-2 max-w-[80%]">
                    <p className="text-sm text-foreground">
                      Perfect! I've booked your appointment for tomorrow at 2:00 PM. You'll receive a confirmation and reminder shortly. Is there anything else I can help with?
                    </p>
                  </div>
                </motion.div>
              </div>

              {/* Typing indicator */}
              <div className="mt-4 pt-4 border-t border-border">
                <div className="flex items-center gap-2 text-muted-foreground text-sm">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 rounded-full bg-cyan-glow animate-pulse" />
                    <span className="w-2 h-2 rounded-full bg-cyan-glow animate-pulse [animation-delay:150ms]" />
                    <span className="w-2 h-2 rounded-full bg-cyan-glow animate-pulse [animation-delay:300ms]" />
                  </div>
                  <span>AI Agent responding 24/7</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SolutionSection;
