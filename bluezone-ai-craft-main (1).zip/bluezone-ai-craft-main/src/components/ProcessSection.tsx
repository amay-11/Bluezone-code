import { Search, PenTool, Code, Rocket, LineChart, ArrowDown } from "lucide-react";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const steps = [
  {
    step: "01",
    icon: Search,
    title: "Business Analysis",
    description: "We study your business operations, customer interactions, and pain points to understand exactly what you need.",
    duration: "Day 1-2",
  },
  {
    step: "02",
    icon: PenTool,
    title: "Agent Design",
    description: "We design a custom AI agent architecture tailored to your specific workflows and customer journey.",
    duration: "Day 2-3",
  },
  {
    step: "03",
    icon: Code,
    title: "Development & Testing",
    description: "We build and rigorously test your AI agent to ensure it handles real-world scenarios effectively.",
    duration: "Day 3-5",
  },
  {
    step: "04",
    icon: Rocket,
    title: "Deployment",
    description: "We deploy your agent to WhatsApp, your website, or both — with seamless integration into your systems.",
    duration: "Day 5-6",
  },
  {
    step: "05",
    icon: LineChart,
    title: "Monitoring & Optimization",
    description: "We continuously monitor performance and optimize the agent based on real customer interactions.",
    duration: "Ongoing",
  },
];

const ProcessSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="process" className="py-24 relative section-glow overflow-hidden">
      <FloatingShapes variant="sparse" />

      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-electric/5 rounded-full blur-[150px]" />
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-cyan-glow/5 rounded-full blur-[120px]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="max-w-3xl mx-auto text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
          >
            <Rocket className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">5-Step Process</span>
          </motion.div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our <span className="text-gradient-blue">Process</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            A proven methodology to deliver AI agents that work from day one.
          </p>
        </AnimatedSection>

        {/* Process Steps */}
        <div ref={ref} className="relative max-w-4xl mx-auto">
          {/* Connection Line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-cyan-glow/50 to-border hidden md:block" />

          <div className="space-y-12">
            {steps.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -40 : 40 }}
                animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: index % 2 === 0 ? -40 : 40 }}
                transition={{
                  duration: 0.6,
                  delay: index * 0.15,
                  ease: [0.25, 0.4, 0.25, 1],
                }}
                className={`relative flex flex-col md:flex-row gap-8 ${
                  index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                {/* Content */}
                <div className={`flex-1 ${index % 2 === 0 ? "md:text-right" : "md:text-left"}`}>
                  <div
                    className={`inline-block p-6 rounded-xl bg-gradient-to-br from-[#0a1628]/90 via-card to-[#081020]/90 border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-[0_0_30px_hsl(var(--blue-electric)/0.1)] ${
                      index % 2 === 0 ? "md:ml-auto" : ""
                    }`}
                  >
                    <div className={`flex items-center gap-4 mb-3 ${index % 2 === 0 ? "md:flex-row-reverse" : ""}`}>
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary/20 to-cyan-glow/10 flex items-center justify-center shrink-0 shadow-[0_0_15px_hsl(var(--blue-electric)/0.15)]">
                        <item.icon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <span className="text-sm font-mono text-primary">{item.step}</span>
                        <p className="text-xs text-cyan-glow/60">{item.duration}</p>
                      </div>
                    </div>
                    <h3 className="font-display font-bold text-lg text-foreground mb-2">
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed max-w-sm">
                      {item.description}
                    </p>
                  </div>
                </div>

                {/* Center Dot with pulse */}
                <div className="absolute left-8 md:left-1/2 top-8 -translate-x-1/2 hidden md:block">
                  <div className="w-4 h-4 rounded-full bg-primary border-4 border-background" />
                  <motion.div
                    className="absolute inset-0 rounded-full bg-primary/30"
                    animate={{ scale: [1, 2, 1], opacity: [0.5, 0, 0.5] }}
                    transition={{ duration: 2, repeat: Infinity, delay: index * 0.3 }}
                  />
                </div>

                {/* Empty space for alternating layout */}
                <div className="flex-1 hidden md:block" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
