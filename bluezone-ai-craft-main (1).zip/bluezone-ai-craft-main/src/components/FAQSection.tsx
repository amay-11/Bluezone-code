import AnimatedSection from "./AnimatedSection";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "What exactly is an AI agent?",
    answer:
      "An AI agent is an intelligent software assistant that can handle tasks like customer support, lead qualification, appointment booking, and more — automatically, 24/7. It learns from your business context to provide accurate, human-like interactions.",
  },
  {
    question: "How long does it take to set up?",
    answer:
      "Most AI agents are fully deployed within 5–7 business days. This includes business analysis, agent configuration, testing, and go-live support.",
  },
  {
    question: "Do I need any technical knowledge?",
    answer:
      "Not at all. We handle everything from setup to deployment. You just provide your business details and goals — we take care of the rest.",
  },
  {
    question: "Can the AI agent integrate with my existing tools?",
    answer:
      "Yes! Our AI agents integrate with popular platforms like WhatsApp, Instagram, websites, CRMs, Google Sheets, and more. We customize integrations based on your workflow.",
  },
  {
    question: "What happens if the AI can't answer a question?",
    answer:
      "The agent is designed to gracefully hand off complex queries to a human team member. You'll get notified instantly so no customer is left waiting.",
  },
  {
    question: "Is there a contract or lock-in period?",
    answer:
      "No long-term contracts. Our plans are month-to-month, so you can upgrade, downgrade, or cancel anytime.",
  },
  {
    question: "How is pricing structured?",
    answer:
      "We have a one-time setup fee of ₹12,000 (~$135) and monthly plans starting from ₹7,000 (~$77). Check our pricing section for full details.",
  },
  {
    question: "What kind of businesses benefit from AI agents?",
    answer:
      "Any business that handles customer inquiries, bookings, or lead generation — including e-commerce, real estate, healthcare clinics, coaching businesses, restaurants, and service providers.",
  },
];

const FAQSection = () => {
  return (
    <section className="py-20 md:py-28 relative" id="faq">
      <div className="container mx-auto px-6 max-w-3xl">
        <AnimatedSection>
          <div className="text-center mb-12">
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              FAQ
            </span>
            <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Everything you need to know about our AI agent solutions.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection delay={0.15}>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border-border/50"
              >
                <AccordionTrigger className="text-left text-foreground hover:text-primary hover:no-underline text-base">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </AnimatedSection>
      </div>
    </section>
  );
};

export default FAQSection;
