import { Headphones, TrendingUp, Calendar, Settings, ArrowRight, Layers } from "lucide-react";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const services = [
  {
    icon: Headphones,
    title: "AI Customer Support Agents",
    description: "Handle customer inquiries automatically with intelligent, context-aware responses.",
    features: ["24/7 automated support", "Website & WhatsApp integration", "Multi-language support"],
    tag: "Most Popular",
  },
  {
    icon: TrendingUp,
    title: "AI Sales & Lead Qualification",
    description: "Capture, qualify, and nurture leads automatically — never miss an opportunity.",
    features: ["Lead capture and filtering", "Automated follow-ups", "CRM integration"],
    tag: "High ROI",
  },
  {
    icon: Calendar,
    title: "Appointment Booking Agents",
    description: "Let customers book appointments anytime without manual scheduling overhead.",
    features: ["Real-time scheduling", "Calendar sync", "Automated reminders"],
    tag: "Time Saver",
  },
  {
    icon: Settings,
    title: "Business Workflow Automation",
    description: "Streamline internal processes and eliminate repetitive manual tasks.",
    features: ["Internal process automation", "Operational efficiency", "Custom workflows"],
    tag: "Enterprise",
  },
];

const ServicesSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="services" className="py-24 relative overflow-hidden bg-[#050810]">
      <FloatingShapes variant="dense" />
      
      {/* Glowing background effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-0 w-80 h-80 bg-blue-electric/6 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-glow/5 rounded-full blur-[150px]" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/4 rounded-full blur-[100px]" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="max-w-3xl mx-auto text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
          >
            <Layers className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">What We Offer</span>
          </motion.div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our <span className="text-gradient-blue">Services</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Production-ready AI agents tailored to your specific business needs.
          </p>
        </AnimatedSection>

        {/* Services Grid */}
        <div ref={ref} className="grid md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
              transition={{
                duration: 0.6,
                delay: index * 0.15,
                ease: [0.25, 0.4, 0.25, 1],
              }}
              className="group relative p-8 rounded-2xl bg-gradient-to-br from-[#0a1628]/90 via-[#0d1a30]/80 to-[#081020]/90 border border-cyan-glow/15 hover:border-cyan-glow/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_0_40px_rgba(34,211,238,0.12),inset_0_1px_0_rgba(34,211,238,0.1)] overflow-hidden"
            >
              {/* Top accent line */}
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-glow/30 to-transparent" />

              {/* Tag */}
              <div className="absolute top-4 right-4">
                <span className="text-[10px] uppercase tracking-widest text-cyan-glow/50 font-semibold px-2 py-1 rounded-full border border-cyan-glow/15 bg-cyan-glow/5">
                  {service.tag}
                </span>
              </div>

              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-cyan-glow/15 to-blue-electric/10 flex items-center justify-center mb-6 group-hover:shadow-[0_0_25px_rgba(34,211,238,0.2)] transition-all">
                <service.icon className="w-7 h-7 text-cyan-glow drop-shadow-[0_0_6px_rgba(34,211,238,0.5)]" />
              </div>

              <h3 className="font-display font-bold text-xl text-foreground mb-3">
                {service.title}
              </h3>

              <p className="text-muted-foreground mb-6 leading-relaxed">
                {service.description}
              </p>

              <ul className="space-y-3">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-3 text-sm text-muted-foreground">
                    <div className="w-1.5 h-1.5 rounded-full bg-cyan-glow shadow-[0_0_6px_rgba(34,211,238,0.5)]" />
                    {feature}
                  </li>
                ))}
              </ul>

              <div className="mt-6 pt-6 border-t border-border">
                <a
                  href="#pricing"
                  className="inline-flex items-center gap-2 text-primary text-sm font-medium group/link"
                >
                  View Pricing
                  <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                </a>
              </div>

              {/* Corner decoration */}
              <div className="absolute bottom-0 right-0 w-20 h-20 opacity-5">
                <div className="absolute bottom-0 right-0 w-full h-full border-b border-r border-cyan-glow rounded-br-2xl" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
