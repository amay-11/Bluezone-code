import { AlertCircle, Clock, UserX, Mail, PhoneOff, Cog, AlertTriangle } from "lucide-react";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const problems = [
  {
    icon: Mail,
    title: "Repetitive Customer Queries",
    description: "Your team spends hours answering the same questions over and over again.",
    stat: "60%",
    statLabel: "time wasted",
  },
  {
    icon: UserX,
    title: "Missed Leads",
    description: "Potential customers slip away because no one was available to respond in time.",
    stat: "35%",
    statLabel: "leads lost",
  },
  {
    icon: Clock,
    title: "Manual Follow-ups",
    description: "Tracking and following up with leads manually is time-consuming and error-prone.",
    stat: "4hrs",
    statLabel: "daily avg",
  },
  {
    icon: AlertCircle,
    title: "High Staff Workload",
    description: "Your team is stretched thin handling tasks that could be automated.",
    stat: "80%",
    statLabel: "repetitive tasks",
  },
  {
    icon: PhoneOff,
    title: "Slow Response Times",
    description: "Customers expect instant responses, but your team can't keep up 24/7.",
    stat: "5min",
    statLabel: "avg delay",
  },
  {
    icon: Cog,
    title: "Operational Inefficiencies",
    description: "Manual processes create bottlenecks that slow down your entire operation.",
    stat: "40%",
    statLabel: "productivity loss",
  },
];

const ProblemSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="py-24 relative overflow-hidden">
      <FloatingShapes variant="sparse" />
      
      {/* Background accents */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-80 h-80 bg-destructive/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-blue-electric/5 rounded-full blur-[150px]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="max-w-3xl mx-auto text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-destructive/10 border border-destructive/20 mb-6"
          >
            <AlertTriangle className="w-4 h-4 text-destructive" />
            <span className="text-sm text-destructive font-medium">Common Pain Points</span>
          </motion.div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Sound Familiar?
          </h2>
          <p className="text-lg text-muted-foreground">
            These common challenges cost businesses time, money, and growth opportunities every day.
          </p>
        </AnimatedSection>

        {/* Problems Grid */}
        <div ref={ref} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {problems.map((problem, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{
                duration: 0.5,
                delay: index * 0.1,
                ease: [0.25, 0.4, 0.25, 1],
              }}
              className="group relative p-6 rounded-xl bg-gradient-to-br from-[#0a1628]/90 via-[#0d1a30]/80 to-[#081020]/90 border border-border hover:border-destructive/30 transition-all duration-300 overflow-hidden"
            >
              {/* Corner decoration */}
              <div className="absolute top-0 right-0 w-16 h-16 opacity-10">
                <div className="absolute top-0 right-0 w-full h-full border-t border-r border-destructive/50 rounded-tr-xl" />
              </div>

              {/* Stat badge */}
              <div className="absolute top-4 right-4">
                <span className="text-xl font-bold text-destructive/60 font-display">{problem.stat}</span>
                <p className="text-[10px] text-muted-foreground/50 text-right">{problem.statLabel}</p>
              </div>

              <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center mb-4 group-hover:bg-destructive/20 transition-colors group-hover:shadow-[0_0_20px_rgba(239,68,68,0.2)]">
                <problem.icon className="w-6 h-6 text-destructive" />
              </div>
              <h3 className="font-display font-semibold text-lg text-foreground mb-2">
                {problem.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {problem.description}
              </p>

              {/* Bottom accent line */}
              <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-destructive/20 to-transparent" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
