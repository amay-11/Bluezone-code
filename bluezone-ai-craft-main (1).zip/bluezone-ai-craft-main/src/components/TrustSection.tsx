import { Shield, Eye, Lock, Users, BadgeCheck, ArrowRight } from "lucide-react";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const trustPoints = [
  {
    icon: Users,
    title: "Organic Client Acquisition",
    description: "We've built our reputation through results, not advertising. Our clients come to us through referrals and demonstrated outcomes.",
    highlight: "Trust-Based Growth",
  },
  {
    icon: Eye,
    title: "Real Business Use Cases",
    description: "Every solution we build is grounded in practical, real-world business scenarios — no theoretical concepts or prototypes.",
    highlight: "Proven Solutions",
  },
  {
    icon: Shield,
    title: "Ethical AI Usage",
    description: "We design AI agents that are transparent, helpful, and honest. No deceptive practices or misleading automation.",
    highlight: "100% Transparent",
  },
  {
    icon: Lock,
    title: "Data Security & Privacy",
    description: "Your business data and customer information are protected with enterprise-grade security measures and strict privacy protocols.",
    highlight: "Enterprise-Grade",
  },
];

const TrustSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <FloatingShapes variant="sparse" />

      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[300px] bg-cyan-glow/5 rounded-full blur-[150px]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="max-w-3xl mx-auto text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-glow/10 border border-cyan-glow/20 mb-6"
          >
            <BadgeCheck className="w-4 h-4 text-cyan-glow" />
            <span className="text-sm text-cyan-glow font-medium">Why Choose Us</span>
          </motion.div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why Trust <span className="text-gradient-blue">BlueZone</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            We're committed to delivering AI solutions that are effective, ethical, and secure.
          </p>
        </AnimatedSection>

        {/* Trust Points Grid */}
        <div ref={ref} className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {trustPoints.map((point, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{
                duration: 0.5,
                delay: index * 0.1,
                ease: [0.25, 0.4, 0.25, 1],
              }}
              className="group relative flex gap-5 p-6 rounded-xl bg-gradient-to-br from-[#0a1628]/90 via-[#0d1a30]/80 to-[#081020]/90 border border-cyan-glow/10 hover:border-cyan-glow/30 transition-all duration-300 hover:shadow-[0_0_30px_rgba(34,211,238,0.08)] overflow-hidden"
            >
              {/* Top accent */}
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-glow/20 to-transparent" />

              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-glow/15 to-blue-electric/10 flex items-center justify-center shrink-0 group-hover:shadow-[0_0_20px_rgba(34,211,238,0.15)] transition-all">
                <point.icon className="w-6 h-6 text-cyan-glow drop-shadow-[0_0_6px_rgba(34,211,238,0.5)]" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] uppercase tracking-widest text-cyan-glow/60 font-semibold">{point.highlight}</span>
                </div>
                <h3 className="font-display font-semibold text-lg text-foreground mb-2">
                  {point.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {point.description}
                </p>
              </div>

              {/* Corner dot */}
              <div className="absolute bottom-3 right-3 w-1.5 h-1.5 rounded-full bg-cyan-glow/30" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
