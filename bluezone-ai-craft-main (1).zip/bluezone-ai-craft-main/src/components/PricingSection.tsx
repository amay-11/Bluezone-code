import { Check, Zap, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const PricingSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="pricing" className="py-24 relative overflow-hidden bg-[#040609]">
      <FloatingShapes variant="dense" />
      
      {/* Glowing background effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-blue-electric/8 rounded-full blur-[150px]" />
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-cyan-glow/6 rounded-full blur-[120px]" />
        <div className="absolute top-1/2 right-0 w-80 h-80 bg-primary/5 rounded-full blur-[100px]" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Transparent Pricing
          </h2>
          <p className="text-lg text-muted-foreground">
            Clear, straightforward pricing with no hidden costs. Start with a one-time setup, 
            then choose the plan that fits your needs.
          </p>
        </AnimatedSection>

        {/* Setup Fee Card */}
        <AnimatedSection delay={0.1} className="max-w-md mx-auto mb-12">
          <div className="p-6 rounded-xl bg-[#0a0f1a]/80 border border-cyan-glow/10 text-center hover:border-cyan-glow/30 transition-all duration-300 hover:shadow-[0_0_40px_rgba(34,211,238,0.1)]">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-glow/10 text-cyan-glow text-sm font-medium mb-4 shadow-[0_0_15px_rgba(34,211,238,0.2)]">
              <Zap className="w-4 h-4" />
              One-Time Setup
            </div>
            <div className="flex items-baseline justify-center gap-1 mb-2">
              <span className="text-3xl font-display font-bold text-foreground">₹12,000</span>
              <span className="text-muted-foreground text-sm">≈ $135</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Includes business analysis, AI agent setup, initial deployment, and basic customization
            </p>
          </div>
        </AnimatedSection>

        {/* Monthly Plans */}
        <div ref={ref} className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Standard Plan */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
            transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
            className="relative p-8 rounded-2xl bg-[#0a0f1a]/80 border border-cyan-glow/10 hover:border-cyan-glow/30 transition-all duration-300 hover:shadow-[0_0_40px_rgba(34,211,238,0.1)]"
          >
            <h3 className="font-display font-bold text-xl text-foreground mb-2">
              Standard Plan
            </h3>
            <div className="flex items-baseline gap-1 mb-1">
              <span className="text-4xl font-display font-bold text-foreground">₹7,000</span>
              <span className="text-muted-foreground">/month</span>
            </div>
            <p className="text-sm text-muted-foreground mb-6">Starting from ≈ $77/month</p>

            <ul className="space-y-4 mb-8">
              {[
                "1 AI agent",
                "WhatsApp or website integration",
                "Basic support",
                "Maintenance & updates",
              ].map((feature, index) => (
                <li key={index} className="flex items-center gap-3 text-muted-foreground">
                  <Check className="w-5 h-5 text-cyan-glow shrink-0 drop-shadow-[0_0_4px_rgba(34,211,238,0.5)]" />
                  {feature}
                </li>
              ))}
            </ul>

            <Button 
              variant="heroOutline" 
              size="lg" 
              className="w-full"
              onClick={() => window.open('https://wa.me/919930157991?text=Hi, I am interested in the Standard Plan', '_blank')}
            >
              Get Started
            </Button>
          </motion.div>

          {/* Advanced Plan */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 30 }}
            transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
            className="relative p-8 rounded-2xl bg-[#0a0f1a]/80 border-2 border-primary shadow-[0_0_50px_hsl(var(--blue-electric)/0.2)]"
          >
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <div className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-gradient-to-r from-blue-electric to-cyan-glow text-white text-sm font-semibold shadow-[0_0_20px_rgba(34,211,238,0.4)]">
                <Star className="w-4 h-4" />
                Recommended
              </div>
            </div>

            <h3 className="font-display font-bold text-xl text-foreground mb-2">
              Advanced Plan
            </h3>
            <div className="flex items-baseline gap-1 mb-1">
              <span className="text-4xl font-display font-bold text-foreground">₹8,500</span>
              <span className="text-muted-foreground">/month</span>
            </div>
            <p className="text-sm text-muted-foreground mb-6">Starting from ≈ $95/month</p>

            <ul className="space-y-4 mb-8">
              {[
                "Multiple AI agents",
                "Advanced automation workflows",
                "Priority support",
                "Ongoing optimization",
                "Analytics & performance monitoring",
              ].map((feature, index) => (
                <li key={index} className="flex items-center gap-3 text-muted-foreground">
                  <Check className="w-5 h-5 text-cyan-glow shrink-0 drop-shadow-[0_0_4px_rgba(34,211,238,0.5)]" />
                  {feature}
                </li>
              ))}
            </ul>

            <Button 
              variant="cta" 
              size="lg" 
              className="w-full"
              onClick={() => window.open('https://wa.me/919930157991?text=Hi, I am interested in the Advanced Plan', '_blank')}
            >
              Get Started
            </Button>
          </motion.div>
        </div>

        {/* Note */}
        <AnimatedSection delay={0.3} className="mt-8">
          <p className="text-center text-sm text-muted-foreground max-w-xl mx-auto">
            Pricing shown as "starting from" to accommodate custom requirements. 
            Contact us for a tailored quote based on your specific needs.
          </p>
        </AnimatedSection>
      </div>
    </section>
  );
};

export default PricingSection;
