import { Clock, Target, Users, Sparkles, TrendingUp, ArrowUpRight } from "lucide-react";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView, useMotionValue, useTransform, animate } from "framer-motion";
import { useRef, useEffect, useState } from "react";

const results = [
  {
    icon: Clock,
    metric: "Faster Response",
    description: "Instant 24/7 responses to customer inquiries without delays.",
    counter: "24/7",
    accent: "Available",
  },
  {
    icon: Target,
    metric: "Better Lead Handling",
    description: "Capture and qualify every lead with consistent follow-up processes.",
    counter: "100%",
    accent: "Capture Rate",
  },
  {
    icon: Users,
    metric: "Reduced Workload",
    description: "Free your team from repetitive tasks to focus on high-value work.",
    counter: "80%",
    accent: "Less Manual",
  },
  {
    icon: Sparkles,
    metric: "Enhanced Experience",
    description: "Deliver personalized, professional customer interactions at scale.",
    counter: "5x",
    accent: "Satisfaction",
  },
];

const AnimatedCounter = ({ value, isInView }: { value: string; isInView: boolean }) => {
  const [displayed, setDisplayed] = useState("0");

  useEffect(() => {
    if (!isInView) return;
    // Simple reveal after delay
    const timer = setTimeout(() => setDisplayed(value), 300);
    return () => clearTimeout(timer);
  }, [isInView, value]);

  return (
    <motion.span
      className="text-3xl font-display font-bold text-gradient-blue"
      initial={{ opacity: 0, scale: 0.5 }}
      animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.5 }}
      transition={{ duration: 0.5, type: "spring" }}
    >
      {displayed}
    </motion.span>
  );
};

const ResultsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="py-24 relative overflow-hidden">
      <FloatingShapes variant="sparse" />

      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-glow/5 rounded-full blur-[200px]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="max-w-3xl mx-auto text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-glow/10 border border-cyan-glow/20 mb-6"
          >
            <TrendingUp className="w-4 h-4 text-cyan-glow" />
            <span className="text-sm text-cyan-glow font-medium">Measurable Impact</span>
          </motion.div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Real Results for <span className="text-gradient-blue">Real Businesses</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Our AI agents deliver measurable improvements across key business metrics.
          </p>
        </AnimatedSection>

        {/* Results Grid */}
        <div ref={ref} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {results.map((result, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
              transition={{
                duration: 0.5,
                delay: index * 0.1,
                ease: [0.25, 0.4, 0.25, 1],
              }}
              className="relative p-6 rounded-xl bg-gradient-to-br from-[#0a1628]/90 via-[#0d1a30]/80 to-[#081020]/90 border border-cyan-glow/10 text-center group hover:border-cyan-glow/30 transition-all duration-300 hover:shadow-[0_0_30px_rgba(34,211,238,0.1)] overflow-hidden"
            >
              {/* Top accent line */}
              <div className="absolute top-0 left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-cyan-glow/40 to-transparent" />

              {/* Animated counter */}
              <div className="mb-3">
                <AnimatedCounter value={result.counter} isInView={isInView} />
                <p className="text-xs text-cyan-glow/60 font-medium mt-1">{result.accent}</p>
              </div>

              <div className="w-12 h-12 rounded-full bg-cyan-glow/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-cyan-glow/20 transition-colors group-hover:shadow-[0_0_20px_rgba(34,211,238,0.15)]">
                <result.icon className="w-6 h-6 text-cyan-glow drop-shadow-[0_0_6px_rgba(34,211,238,0.5)]" />
              </div>
              <h3 className="font-display font-bold text-lg text-foreground mb-2 flex items-center justify-center gap-1">
                {result.metric}
                <ArrowUpRight className="w-4 h-4 text-cyan-glow/50" />
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {result.description}
              </p>

              {/* Corner dot */}
              <div className="absolute bottom-3 right-3 w-2 h-2 rounded-full bg-cyan-glow/20" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ResultsSection;
