import { Button } from "@/components/ui/button";
import { ArrowRight, Bot, Zap, Shield, Sparkles } from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import FloatingShapes from "./FloatingShapes";

const HeroSection = () => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  // Floating particles data
  const particles = [
    { size: 4, x: "10%", y: "20%", delay: 0, duration: 8 },
    { size: 6, x: "85%", y: "15%", delay: 1, duration: 10 },
    { size: 3, x: "70%", y: "70%", delay: 2, duration: 7 },
    { size: 5, x: "20%", y: "80%", delay: 0.5, duration: 9 },
    { size: 4, x: "90%", y: "50%", delay: 1.5, duration: 11 },
    { size: 3, x: "5%", y: "60%", delay: 3, duration: 8 },
    { size: 5, x: "50%", y: "10%", delay: 2.5, duration: 12 },
    { size: 4, x: "40%", y: "85%", delay: 0.8, duration: 9 },
  ];

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Floating Geometric Shapes */}
      <FloatingShapes variant="dense" />
      {/* Animated Background Gradient Orbs */}
      <motion.div 
        style={{ y }}
        className="absolute inset-0"
      >
        {/* Primary gradient orb */}
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.08, 0.12, 0.08],
          }}
          transition={{ 
            duration: 8, 
            repeat: Infinity, 
            ease: "easeInOut" 
          }}
          className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/4 w-[1000px] h-[1000px] bg-[radial-gradient(ellipse_at_center,hsl(var(--blue-electric)/0.15)_0%,transparent_60%)]" 
        />
        
        {/* Secondary cyan orb */}
        <motion.div 
          animate={{ 
            scale: [1.2, 1, 1.2],
            x: [0, 50, 0],
            opacity: [0.05, 0.1, 0.05],
          }}
          transition={{ 
            duration: 10, 
            repeat: Infinity, 
            ease: "easeInOut",
            delay: 2 
          }}
          className="absolute top-1/3 right-0 w-[800px] h-[800px] bg-[radial-gradient(circle,hsl(var(--cyan-glow)/0.1)_0%,transparent_50%)]" 
        />
        
        {/* Tertiary orb - bottom left */}
        <motion.div 
          animate={{ 
            scale: [1, 1.3, 1],
            y: [0, -30, 0],
            opacity: [0.06, 0.1, 0.06],
          }}
          transition={{ 
            duration: 12, 
            repeat: Infinity, 
            ease: "easeInOut",
            delay: 4 
          }}
          className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-[radial-gradient(circle,hsl(var(--blue-electric)/0.1)_0%,transparent_60%)]" 
        />
      </motion.div>

      {/* Floating Particles */}
      {particles.map((particle, index) => (
        <motion.div
          key={index}
          className="absolute rounded-full bg-cyan-glow/30"
          style={{
            width: particle.size,
            height: particle.size,
            left: particle.x,
            top: particle.y,
          }}
          animate={{
            y: [0, -30, 0],
            opacity: [0.3, 0.7, 0.3],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: particle.duration,
            repeat: Infinity,
            ease: "easeInOut",
            delay: particle.delay,
          }}
        />
      ))}

      {/* Animated Grid Pattern */}
      <motion.div 
        className="absolute inset-0 opacity-[0.03]"
        animate={{
          backgroundPosition: ["0px 0px", "60px 60px"],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
        style={{
          backgroundImage: `linear-gradient(hsl(var(--cyan-glow)) 1px, transparent 1px),
                           linear-gradient(90deg, hsl(var(--cyan-glow)) 1px, transparent 1px)`,
          backgroundSize: '60px 60px'
        }}
      />

      {/* Horizontal Scan Lines Effect */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.015]"
        style={{
          backgroundImage: `repeating-linear-gradient(
            0deg,
            transparent,
            transparent 2px,
            hsl(var(--cyan-glow)) 2px,
            hsl(var(--cyan-glow)) 4px
          )`,
        }}
      />

      {/* Corner Accent Lines */}
      <div className="absolute top-20 left-8 w-32 h-32 border-l-2 border-t-2 border-cyan-glow/20 rounded-tl-3xl" />
      <div className="absolute top-20 right-8 w-32 h-32 border-r-2 border-t-2 border-blue-electric/20 rounded-tr-3xl" />
      <div className="absolute bottom-20 left-8 w-32 h-32 border-l-2 border-b-2 border-blue-electric/20 rounded-bl-3xl" />
      <div className="absolute bottom-20 right-8 w-32 h-32 border-r-2 border-b-2 border-cyan-glow/20 rounded-br-3xl" />

      <motion.div style={{ opacity }} className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Trust Badge with Shimmer */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-muted/60 via-muted/40 to-muted/60 border border-cyan-glow/30 mb-8 overflow-hidden animate-border-glow"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-glow/10 to-transparent animate-shimmer" />
            <Sparkles className="w-4 h-4 text-cyan-glow animate-pulse" />
            <span className="text-sm text-foreground/90 font-medium relative z-10">
              Already delivering measurable results through organic client acquisition
            </span>
          </motion.div>

          {/* Main Headline with Glow Effect */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="font-display text-4xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight"
          >
            AI Agents Built for{" "}
            <span className="text-gradient-blue animate-text-glow relative">
              Real Businesses
              <motion.span
                className="absolute -inset-2 bg-cyan-glow/5 rounded-lg blur-xl -z-10"
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            We design and deploy custom AI agents that automate customer communication, 
            operations, and sales — helping businesses save time and scale efficiently.
          </motion.p>

          {/* CTA Buttons with Enhanced Effects */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
          >
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="relative"
            >
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-glow/50 to-blue-electric/50 rounded-xl blur-lg opacity-50 group-hover:opacity-75 animate-pulse-slow" />
              <Button 
                variant="cta" 
                size="xl" 
                className="group relative"
                onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <Sparkles className="w-4 h-4 mr-2 animate-bounce-gentle" />
                Request a Strategy Call
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button 
                variant="heroOutline" 
                size="xl" 
                className="animate-border-glow"
                onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
              >
                View Our Services
              </Button>
            </motion.div>
          </motion.div>

          {/* Feature Pills with Hover Effects */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="flex flex-wrap items-center justify-center gap-4 md:gap-6"
          >
            {[
              { icon: Bot, label: "Custom AI Agents", delay: 0 },
              { icon: Zap, label: "24/7 Automation", delay: 0.1 },
              { icon: Shield, label: "Enterprise Security", delay: 0.2 },
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 + feature.delay }}
                whileHover={{ scale: 1.05, y: -2 }}
                className="flex items-center gap-2 px-4 py-2 rounded-full glass-effect cursor-default"
              >
                <feature.icon className="w-4 h-4 text-cyan-glow drop-shadow-[0_0_8px_hsl(var(--cyan-glow)/0.5)]" />
                <span className="text-sm text-foreground/80">{feature.label}</span>
              </motion.div>
            ))}
          </motion.div>

          {/* Animated Decorative Ring */}
          <motion.div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] md:w-[800px] md:h-[800px] pointer-events-none"
            animate={{ rotate: 360 }}
            transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
          >
            <div className="absolute inset-0 rounded-full border border-cyan-glow/5" />
            <div className="absolute inset-8 rounded-full border border-blue-electric/5 border-dashed" />
            <div className="absolute inset-16 rounded-full border border-cyan-glow/5" />
          </motion.div>
        </div>
      </motion.div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};

export default HeroSection;
