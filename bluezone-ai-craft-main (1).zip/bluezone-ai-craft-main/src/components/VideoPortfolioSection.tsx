import { Play, ExternalLink } from "lucide-react";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import { AspectRatio } from "@/components/ui/aspect-ratio";

const videos = [
  {
    id: 1,
    title: "AI Customer Support Agent Demo",
    description: "See how our AI agent handles real customer queries for a retail business.",
    thumbnail: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=450&fit=crop",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    duration: "3:45",
  },
  {
    id: 2,
    title: "Appointment Booking Automation",
    description: "Watch our AI seamlessly manage appointment scheduling for a dental clinic.",
    thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=450&fit=crop",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    duration: "4:20",
  },
];

const VideoPortfolioSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [activeVideo, setActiveVideo] = useState<number | null>(null);

  return (
    <section id="portfolio" className="py-24 relative overflow-hidden">
      <FloatingShapes variant="default" />
      
      {/* Background gradient */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,hsl(var(--blue-electric)/0.05)_0%,transparent_50%)]" />

      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-glow/10 text-cyan-glow text-sm font-medium mb-6">
            <Play className="w-4 h-4" />
            Video Portfolio
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            See Our AI Agents in Action
          </h2>
          <p className="text-lg text-muted-foreground">
            Watch real demonstrations of how our AI solutions transform business operations.
          </p>
        </AnimatedSection>

        {/* Videos Grid */}
        <div ref={ref} className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {videos.map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
              transition={{
                duration: 0.6,
                delay: index * 0.2,
                ease: [0.25, 0.4, 0.25, 1],
              }}
              className="group"
            >
              <div className="relative rounded-2xl overflow-hidden bg-card border border-border hover:border-cyan-glow/40 transition-all duration-300">
                {activeVideo === video.id ? (
                  <AspectRatio ratio={16 / 9}>
                    <iframe
                      src={video.videoUrl}
                      className="w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </AspectRatio>
                ) : (
                  <AspectRatio ratio={16 / 9}>
                    <div className="relative w-full h-full">
                      <img
                        src={video.thumbnail}
                        alt={video.title}
                        className="w-full h-full object-cover"
                      />
                      {/* Overlay */}
                      <div className="absolute inset-0 bg-navy-deep/60 group-hover:bg-navy-deep/40 transition-colors" />
                      
                      {/* Play Button */}
                      <button
                        onClick={() => setActiveVideo(video.id)}
                        className="absolute inset-0 flex items-center justify-center"
                      >
                        <motion.div
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.95 }}
                          className="w-16 h-16 rounded-full bg-gradient-to-r from-blue-electric to-cyan-glow flex items-center justify-center shadow-[0_0_30px_hsl(var(--blue-electric)/0.4)]"
                        >
                          <Play className="w-7 h-7 text-white ml-1" fill="white" />
                        </motion.div>
                      </button>

                      {/* Duration Badge */}
                      <div className="absolute bottom-3 right-3 px-2 py-1 rounded bg-background/80 text-xs font-medium text-foreground">
                        {video.duration}
                      </div>
                    </div>
                  </AspectRatio>
                )}

                {/* Video Info */}
                <div className="p-5">
                  <h3 className="font-display font-semibold text-lg text-foreground mb-2 group-hover:text-cyan-glow transition-colors">
                    {video.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {video.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View More Link */}
        <AnimatedSection delay={0.4} className="text-center mt-10">
          <a
            href="#"
            className="inline-flex items-center gap-2 text-cyan-glow hover:text-cyan-glow/80 font-medium transition-colors"
          >
            View more case studies
            <ExternalLink className="w-4 h-4" />
          </a>
        </AnimatedSection>
      </div>
    </section>
  );
};

export default VideoPortfolioSection;
