import { ShieldCheck, RefreshCcw, Award, CheckCircle2 } from "lucide-react";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const GuaranteeSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="py-16 relative overflow-hidden">
      <FloatingShapes variant="sparse" />
      
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-electric/5 via-cyan-glow/5 to-blue-electric/5" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
          className="max-w-3xl mx-auto"
        >
          <div className="relative p-8 md:p-10 rounded-2xl bg-gradient-to-br from-[#0a1628] via-[#0d1a30] to-[#081020] border border-cyan-glow/20 shadow-[0_0_60px_rgba(34,211,238,0.08),inset_0_1px_0_rgba(34,211,238,0.1)] overflow-hidden">
            {/* Top accent line */}
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-glow/40 to-transparent" />
            
            {/* Corner decorations */}
            <div className="absolute top-0 left-0 w-12 h-12 border-l border-t border-cyan-glow/20 rounded-tl-2xl" />
            <div className="absolute top-0 right-0 w-12 h-12 border-r border-t border-cyan-glow/20 rounded-tr-2xl" />
            <div className="absolute bottom-0 left-0 w-12 h-12 border-l border-b border-cyan-glow/20 rounded-bl-2xl" />
            <div className="absolute bottom-0 right-0 w-12 h-12 border-r border-b border-cyan-glow/20 rounded-br-2xl" />

            {/* Shield Icon */}
            <div className="absolute -top-6 left-1/2 -translate-x-1/2">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-electric to-cyan-glow flex items-center justify-center shadow-[0_0_25px_rgba(34,211,238,0.3)]">
                <ShieldCheck className="w-6 h-6 text-white" />
              </div>
            </div>

            <div className="text-center pt-4">
              {/* Badge */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.3 }}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-glow/10 border border-cyan-glow/20 mb-4"
              >
                <Award className="w-3 h-3 text-cyan-glow" />
                <span className="text-xs text-cyan-glow font-medium">Our Promise</span>
              </motion.div>

              <h3 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-4">
                16-Day Money-Back Guarantee
              </h3>
              
              <p className="text-lg text-muted-foreground mb-6 max-w-xl mx-auto">
                We're confident in our AI solutions. If within <span className="text-cyan-glow font-semibold animate-text-glow">16 days</span> of deployment you don't see measurable improvements, 
                we'll refund <span className="text-cyan-glow font-semibold animate-text-glow">50% of your setup fee</span>.
              </p>

              <div className="flex items-center justify-center gap-6 flex-wrap">
                <div className="flex items-center gap-2 text-sm text-muted-foreground px-4 py-2 rounded-full bg-cyan-glow/5 border border-cyan-glow/10">
                  <RefreshCcw className="w-4 h-4 text-cyan-glow" />
                  No questions asked
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground px-4 py-2 rounded-full bg-cyan-glow/5 border border-cyan-glow/10">
                  <CheckCircle2 className="w-4 h-4 text-cyan-glow" />
                  Risk-free trial
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-border">
                <p className="text-xs text-muted-foreground">
                  * Guarantee applies to initial setup fee. Monthly subscription fees are non-refundable. 
                  Terms and conditions apply.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default GuaranteeSection;
