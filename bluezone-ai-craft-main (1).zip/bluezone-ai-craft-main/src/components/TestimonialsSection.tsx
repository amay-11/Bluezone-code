import { Quote, Star, MessageSquarePlus, Award } from "lucide-react";
import AnimatedSection from "./AnimatedSection";
import FloatingShapes from "./FloatingShapes";
import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { toast } from "@/hooks/use-toast";

const testimonials = [
  {
    name: "Priya Sharma",
    role: "Owner, Sharma Dental Clinic",
    feedback:
      "BlueZone is very helpful for us. Our appointment bookings increased by 40% after implementing their AI agent. Patients love the instant responses!",
    rating: 5,
    highlight: "+40% Bookings",
  },
  {
    name: "Rajesh Kumar",
    role: "Director, TechMart Electronics",
    feedback:
      "The AI agent handles 80% of our customer queries automatically. Our team can now focus on complex issues. Highly recommend BlueZone!",
    rating: 4,
    highlight: "80% Automated",
  },
  {
    name: "Anita Desai",
    role: "Manager, QuickServe Restaurant Chain",
    feedback:
      "We were skeptical at first, but BlueZone delivered exactly what they promised. Order inquiries and table bookings are now fully automated.",
    rating: 4,
    highlight: "Fully Automated",
  },
  {
    name: "Mohammed Ali",
    role: "Founder, FitLife Gym",
    feedback:
      "BlueZone transformed how we handle member queries. The AI agent manages class bookings, membership inquiries, and follow-ups seamlessly.",
    rating: 5,
    highlight: "3x Efficiency",
  },
];

const TestimonialsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({ name: "", role: "", feedback: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Thank you for your feedback!",
      description: "We appreciate you taking the time to share your experience.",
    });
    setFormData({ name: "", role: "", feedback: "" });
    setIsOpen(false);
  };

  return (
    <section className="py-24 relative overflow-hidden bg-[#050810]">
      <FloatingShapes variant="sparse" />
      
      {/* Glowing background effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-glow/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-electric/5 rounded-full blur-[100px]" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="max-w-3xl mx-auto text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-glow/10 border border-cyan-glow/20 mb-6"
          >
            <Award className="w-4 h-4 text-cyan-glow" />
            <span className="text-sm text-cyan-glow font-medium">Client Success Stories</span>
          </motion.div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            What Our <span className="text-gradient-blue">Clients Say</span>
          </h2>
          <p className="text-lg text-muted-foreground mb-6">
            Real feedback from businesses that trust BlueZone with their AI automation.
          </p>
          
          {/* Add Feedback Button */}
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                className="border-cyan-glow/30 text-cyan-glow hover:bg-cyan-glow/10 hover:border-cyan-glow/50 gap-2"
              >
                <MessageSquarePlus className="w-4 h-4" />
                Share Your Feedback
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#0a0f1a] border-cyan-glow/20">
              <DialogHeader>
                <DialogTitle className="text-foreground">Share Your Experience</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                <Input
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-[#050810] border-border focus:border-cyan-glow/50"
                  required
                />
                <Input
                  placeholder="Your Role & Company"
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="bg-[#050810] border-border focus:border-cyan-glow/50"
                  required
                />
                <Textarea
                  placeholder="Tell us about your experience with BlueZone..."
                  value={formData.feedback}
                  onChange={(e) => setFormData({ ...formData, feedback: e.target.value })}
                  className="bg-[#050810] border-border focus:border-cyan-glow/50 min-h-[100px]"
                  required
                />
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-blue-electric to-cyan-glow text-white hover:opacity-90"
                >
                  Submit Feedback
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </AnimatedSection>

        {/* Testimonials Grid */}
        <div ref={ref} className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{
                duration: 0.5,
                delay: index * 0.15,
                ease: [0.25, 0.4, 0.25, 1],
              }}
              className="relative p-6 rounded-2xl bg-gradient-to-br from-[#0a1628]/90 via-[#0d1a30]/80 to-[#081020]/90 border border-cyan-glow/15 hover:border-cyan-glow/40 transition-all duration-300 hover:shadow-[0_0_40px_rgba(34,211,238,0.12),inset_0_1px_0_rgba(34,211,238,0.1)] overflow-hidden"
            >
              {/* Top accent line */}
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-glow/30 to-transparent" />

              {/* Highlight badge */}
              <div className="absolute top-4 right-4">
                <span className="text-[10px] uppercase tracking-widest text-cyan-glow/60 font-semibold px-2 py-1 rounded-full border border-cyan-glow/15 bg-cyan-glow/5">
                  {testimonial.highlight}
                </span>
              </div>

              {/* Quote Icon with glow */}
              <Quote className="absolute top-12 right-4 w-8 h-8 text-cyan-glow/10" />

              {/* Rating */}
              <div className="flex gap-0.5 mb-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3.5 h-3.5 ${
                      i < testimonial.rating
                        ? "fill-cyan-glow text-cyan-glow drop-shadow-[0_0_4px_rgba(34,211,238,0.5)]"
                        : "text-muted-foreground/30"
                    }`}
                  />
                ))}
              </div>

              {/* Feedback */}
              <p className="text-muted-foreground mb-6 leading-relaxed text-sm">
                "{testimonial.feedback}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-electric to-cyan-glow flex items-center justify-center text-white font-semibold text-sm shadow-[0_0_15px_rgba(34,211,238,0.3)]">
                  {testimonial.name.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">
                    {testimonial.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {testimonial.role}
                  </p>
                </div>
              </div>

              {/* Corner dot */}
              <div className="absolute bottom-3 right-3 w-1.5 h-1.5 rounded-full bg-cyan-glow/20" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
