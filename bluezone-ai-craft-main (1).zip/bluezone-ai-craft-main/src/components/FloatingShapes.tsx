import { motion } from "framer-motion";

interface FloatingShapesProps {
  variant?: "default" | "sparse" | "dense";
}

const FloatingShapes = ({ variant = "default" }: FloatingShapesProps) => {
  const shapes = variant === "sparse" 
    ? [
        { type: "hexagon", size: 40, x: "5%", y: "20%", delay: 0, duration: 20 },
        { type: "circle", size: 25, x: "90%", y: "60%", delay: 2, duration: 18 },
        { type: "ring", size: 50, x: "85%", y: "15%", delay: 1, duration: 22 },
      ]
    : variant === "dense"
    ? [
        { type: "hexagon", size: 35, x: "8%", y: "15%", delay: 0, duration: 18 },
        { type: "circle", size: 20, x: "15%", y: "70%", delay: 1.5, duration: 20 },
        { type: "ring", size: 45, x: "92%", y: "25%", delay: 0.5, duration: 22 },
        { type: "hexagon", size: 25, x: "88%", y: "75%", delay: 2, duration: 19 },
        { type: "circle", size: 30, x: "5%", y: "45%", delay: 1, duration: 21 },
        { type: "ring", size: 35, x: "95%", y: "50%", delay: 2.5, duration: 17 },
      ]
    : [
        { type: "hexagon", size: 40, x: "5%", y: "20%", delay: 0, duration: 20 },
        { type: "circle", size: 25, x: "92%", y: "30%", delay: 1, duration: 18 },
        { type: "ring", size: 50, x: "8%", y: "70%", delay: 2, duration: 22 },
        { type: "hexagon", size: 30, x: "88%", y: "80%", delay: 1.5, duration: 19 },
      ];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {shapes.map((shape, index) => (
        <motion.div
          key={index}
          className="absolute"
          style={{ left: shape.x, top: shape.y }}
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{
            opacity: [0.1, 0.3, 0.1],
            scale: [0.9, 1.1, 0.9],
            rotate: [0, 180, 360],
            y: [-10, 10, -10],
          }}
          transition={{
            duration: shape.duration,
            delay: shape.delay,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          {shape.type === "hexagon" && (
            <svg
              width={shape.size}
              height={shape.size}
              viewBox="0 0 100 100"
              className="text-cyan-glow"
            >
              <polygon
                points="50,2 95,25 95,75 50,98 5,75 5,25"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                opacity="0.4"
              />
            </svg>
          )}
          {shape.type === "circle" && (
            <div
              className="rounded-full border border-blue-electric/30"
              style={{ width: shape.size, height: shape.size }}
            />
          )}
          {shape.type === "ring" && (
            <svg
              width={shape.size}
              height={shape.size}
              viewBox="0 0 100 100"
              className="text-blue-electric"
            >
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeDasharray="10 5"
                opacity="0.3"
              />
            </svg>
          )}
        </motion.div>
      ))}
    </div>
  );
};

export default FloatingShapes;
