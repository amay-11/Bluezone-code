import { Button } from "@/components/ui/button";
import { ArrowRight, Mail, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const CTASection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,hsl(var(--blue-electric)/0.15)_0%,transparent_60%)]" />
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-[radial-gradient(ellipse_at_center,hsl(var(--cyan-glow)/0.1)_0%,transparent_70%)]" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-accent/30 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: [0.25, 0.4, 0.25, 1] }}
          className="max-w-3xl mx-auto text-center"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-effect border border-accent/20 mb-8 animate-border-glow"
          >
            <Sparkles className="w-4 h-4 text-accent animate-pulse" />
            <span className="text-sm text-foreground/80">Let's Build Something Amazing</span>
          </motion.div>

          <h2 className="font-display text-3xl md:text-5xl font-bold text-foreground mb-6">
            Build AI That Actually Works{" "}
            <span className="text-gradient-blue animate-text-glow">for Your Business</span>
          </h2>
          <p className="text-lg text-muted-foreground mb-10 max-w-xl mx-auto">
            Ready to automate your customer communication and operations? 
            Let's discuss how AI agents can transform your business.
          </p>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-accent/50 to-primary/50 rounded-xl blur-lg opacity-50 animate-pulse-slow" />
              <Button 
                variant="cta" 
                size="xl" 
                className="group relative"
                onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Book a Free Strategy Call
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </motion.div>

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button 
                variant="heroOutline" 
                size="xl" 
                className="group animate-border-glow"
                onClick={() => window.location.href = 'mailto:bluezone058@gmail.com'}
              >
                <Mail className="w-4 h-4 mr-2 text-accent group-hover:drop-shadow-[0_0_8px_hsl(var(--cyan-glow)/0.5)]" />
                bluezone058@gmail.com
              </Button>
            </motion.div>
          </motion.div>

          {/* Email highlight */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mt-8 flex items-center justify-center gap-3"
          >
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-accent/40" />
            <p className="text-sm text-muted-foreground">
              No commitment required. Let's explore what's possible.
            </p>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-accent/40" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;
